crie uma landing page para um site de uma empresa de desenvolvimento de software.

o site deve ser responsivo e deve ter um menu de navegação com os seguintes links:
- Home
- Serviços
- Contato

frontend:
- html
- css
- javascript

backend:
- node.js
